INSERT INTO `recommends_bg` (`id`, `area_id`, `img`) VALUES (1, 1, 'upload/images/16.png');
INSERT INTO `recommends_bg` (`id`, `area_id`, `img`) VALUES (2, 2, 'upload/images/b2.jpg');
INSERT INTO `recommends_bg` (`id`, `area_id`, `img`) VALUES (3, 4, 'upload/images/0.png');
